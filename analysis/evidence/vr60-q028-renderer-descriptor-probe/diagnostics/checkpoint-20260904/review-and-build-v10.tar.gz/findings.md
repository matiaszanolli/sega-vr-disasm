# Worker Findings — 2026-08-13

## Q-028 v3-v7 phase-1 correction (latest; supersedes the older Q-028 result below)

**Q-028 status: BLOCKED / INCONCLUSIVE_ENGINE_SCHEDULE.** The prior
`INCONCLUSIVE_COMPOSITE` acceptance is retracted. All former interpreter and DRC-A output is
diagnostic/ineligible and was moved intact to `/tmp/q028-diagnostic-ineligible-v7/`; its 232-file,
15,344,425-byte inventory is retained with `eligible:false` and `reuse_forbidden:true`. No old
hash/result is reusable. No fresh schedule or outcome campaign was run in phase 1.

The corrected pre-capture implementation has a direct hook immediately before the unchanged
`PicoDraw32xLayer` `dram[FS]` selector, a one-render/one-callback token, separate render-select,
post-frame, preapply, and callback manifests, and exact Q-028 applied-input output. The unapproved
automatic `VRD_RECORD_INPUT` path is removed; interactive debugger recording remains explicit.
The observer builds from a pinned pristine PicoDrive source copy and is host-passive.

The production contract and archive validator require 36 capture-on plus four capture-off fresh
packages, exactly 640 renderer-selection page members, per-run floors 9,076,736/7,929,856, and
the 358,481,920-byte pre-log campaign floor. The prospective schedule freezer has an explicit
metadata-only reader allowlist and cannot open outcome bytes. The matrix runner has no reuse,
resume, or adaptive schedule path and requires an Auditor-reviewed schedule hash.

Static owner analysis consumes a 116-MiB VASM linked listing, GNU SH2 decode, and the complete
ordinary ROM. The checked-in domain covers 1,296 linked source postimages, 3,186 executable
ranges, 2,559 literal ranges, and 2,578 resolved symbol expressions. The report retains 10,028
dynamic indirect sites, reports zero unsupported/unclassified/unresolved counts, identifies the
one permitted unaligned `$0202BC35` datum, and expressly makes no global free-memory claim.

All v3-1..v3-14 and v4-1..v4-14 production category mutations executed through the same contract
validator with exact diagnostics; the production ustar/gzip reader also rejects a trailing member.
`make clean && make all && make q028-renderer-probe-roms`, pristine-core compilation, frontend
`-Werror` compilation, static identities, pre-capture/owner gates, the 14-test consolidated suite,
and `git diff --check` pass. The exact unstaged phase-1 allowlist is
`/tmp/q028-stage-paths-v6.txt`, SHA-256
`2257cb8c72d544c5acde221cb5fa6579a4468a318a871a0b5cd1aadb490c23c4`; nothing is staged or
committed. The older sections below are historical diagnostic notes only.

## Task

Implement and execute Q-028 exactly as authorized by the fresh-Auditor-approved v3 renderer
descriptor-family proposal, SHA-256
`2e06bd11cf86a54e172ed754e0252311f1286ee5592e9eaa1961ddccdc561ba6`, and its v4
lossless-capture correction, SHA-256
`ee83dbb39b5277a340db5208357cff8e1e5f3bff7f0b9e02d4f5dfe76921824a`. Preserve all ROM/probe
semantics, ordinary/prior identities, and the frozen decision tree. Permanently quarantine every
pre-v4 pilot. Run no exact-index arm unless exactly one family removes the complete player.

## VR60 phase and roadmap reference

Q-028 is a Phase-5F renderer-discovery gate after Q-027's bounded cmd `$3F` transport pass and
before any renderer bridge, collision/equivalence, authority, bypass, or cadence work.
`VR60_STATUS.md` remains authoritative: the ordinary mode-0 ROM and the original 68000
physics/AI/collision/render-preparation path remain active and authoritative; cmd `$3F` remains
disabled in that default.

The research basis is:

- stock Slave cmd `$02` calls `$060024DC` for A (`$0600C128`, 4 records), B (`$0600C178`, 8
  records), then seven C groups (`$0600C254`, 3 sparse records per group);
- the real PicoDrive compositor displays `dram[FS]`; callback RGB565 bytes are the authoritative
  pre-host-scaling image (`analysis/RENDERING_PIPELINE.md` and the approved v4 delta);
- the 32X VDP FS bit selects DRAM0/DRAM1 and FEN marks fill in progress
  (`docs/32x-hardware-manual.md`, framebuffer control section); and
- all shared SDRAM/system-register observations use the documented cache-through aliases; no new
  COMM owner or handshake is introduced (`analysis/COMM_REGISTERS_HARDWARE_ANALYSIS.md`).

## Implementation complete

The validation-only build now provides mutually exclusive family-all BASELINE/CONTROL/ACTIVE
triplets. At boot the existing IDL copy places the exact 296-byte ROM source
`$02BBC0-$02BCE7` at SDRAM `$0600BBC0-$0600BCE7`; the ordinary image keeps the entire interval
zero. The sole stock literal at file `$021080` selects the wrapper only in Q-028. The wrapper
temporarily substitutes descriptor word `+$00`, performs read/store/read, calls stock
`$060024DC`, restores the exact preimage, and performs the final read. CONTROL and ACTIVE differ
only at file `$02BC3A-$02BC3B`, `$6203->$222A`; the store at `$02BC3E` is unchanged. It writes no
COMM, CMD/DREQ, framebuffer, FBCTL, persistent state, or authority field.

The v4 capture path records exactly one positively negotiated RGB565 callback per `retro_run`,
320x224 with pitch 640 and all 143,360 bytes including row 223. It records both raw 128-KiB pages,
displayed-page selection, FS/FBCTL, both pages immediately before each FS application, WRAM,
SDRAM, complete all-access events, and the exact transaction/context/stack ledgers. The validator
freezes cmd `$02` ordinal 54 at frame 1300, frames 1298-1305, expected FS
`1,0,0,0,1,1,1,0`, and checkpoints 1299/1302/1305. New-directory-only runtime orchestration runs
two repeats per arm, verifies normalized repeat equality, compares each triplet, and encodes the
mandatory stop verdict.

## Static verification

`make q028-renderer-probe-roms` passes. The ordinary and all prior accepted identities remain
exact:

- ordinary/baseline: `6f2768f2cffc85cdc815a67c9f13837112829edac3f0921a57454e79e2523900`;
- A CONTROL/ACTIVE: `4b9ec3de4d3daba011bed3cf33cccbd401d8f56a972be299ad327c94cddc98b7` /
  `864279c45ef98a3402e8a974452d5b00e422580d46b10f12295aefdf18ca4ab9`;
- B CONTROL/ACTIVE: `53da1a380aed2d27ee0be283fefdcf71c617f72e0d8536b3dfe716fac3d68c98` /
  `658348fc47be50525766312114bef835dea636765ce8b7e5a34fa0d802c9123b`;
- C CONTROL/ACTIVE: `cabd40d2c177dcb55106d46ce1682d8c4f67f7e4dd52fd97045a15a39fc94eff` /
  `01bd49c96b00fa1fb7ef5840e9656578bba2adbe62f7ffd3e15d03e3341778e7`.

The static verifier rechecks the boot allocation/guard/zero-run inventory, literal users,
aligned/constructed owner policy, wrapper/ELF identities, fixed PCs, sole pair edge, family
geometry, expansion-ROM exclusion, and every accepted mode-1/mode-2/Q-023/Q-026/Q-027 identity.
Six adversarial static tests cover complete verification plus new interval owner, zero-run,
literal-user, pair-delta, and sparse-C mutations.

## Fresh eligible interpreter result

The immutable fixture is `normal-1p-1340.csv`, SHA-256
`2df0ffe53cad0c7d7a5d70c1819051685905a60ff96727a6256e6a300116fbbf`. The pinned interpreter
core is `6c5dadc8d418790e4814fdb17b6224e64c9694a00a73b88a1e3f7491feca2218`; the frontend is
`b2dca945457e2a4c36c499bf6a0355ea0ad89042d18a2153b773cf0c6c2f8e0e`.

Every one of the 18 fresh runs passes the complete v3/v4 contract and is normalized-byte-exact
against its same-arm repeat. Both triplet summaries per family pass. The selected transaction has
dynamic call order `A,B,Cg0..Cg6`; all wrapper/stock entries, target word events, context/SR/stack
restoration, 68000 writer/register/caller -> DREQ/FIFO -> wrapper -> stock -> restore lineage,
displayed-page equality, both-page pre-FS/checkpoint convergence, and intermediate hidden-page
mismatch tables are complete and repeat-identical.

Family decisions:

- A: exactly 2,831 callback pixels change on every frame 1298-1305 in both repeats. Independent
  inspection of the lossless frame-1302 baseline/active/XOR shows player wheel/tire geometry is
  absent but the player body remains.
- B: both repeats/triplets pass with exactly zero changed callback pixels on every captured frame;
  no presented effect in this fixture.
- C: both repeats/triplets pass with exactly zero changed callback pixels on every captured frame;
  no presented effect in this fixture.

The approved family predicate is complete-player removal. A removes only a component; therefore
no family qualifies. Q-028 is `INCONCLUSIVE_COMPOSITE`, exact-index runs are forbidden, and
`exact_index_runs` is exactly zero.

## Quarantined diagnostics

All artifacts under `/tmp/q028-pilot`, `/tmp/q028-displaydiag`, and `/tmp/q028-late` are permanently
ineligible and hash-bound separately. They do not enter the eligible evidence manifest.

Normal-DRC A was captured twice per arm as diagnosis only. Its fixed host window yields FS
`1,1,1,0,0,0,1,1`, pre-FS frames 1298/1301/1304, and transient FEN, not the approved interpreter
schedule/checkpoints. The mismatch is material; the v4 predicate was not changed. DRC-A is
ineligible, B/C DRC arms were not run, and any future engine-relative schedule needs a fresh
proposal/audit. The small DRC manifests, exact mismatch summary, and hashes are retained in the
evidence quarantine.

## Tests and evidence

- `make clean && make all`: PASS (ordinary identity unchanged).
- `make q028-renderer-probe-roms`: PASS.
- `python3 tools/libretro-profiling/test_verify_q028_renderer_probe_roms.py`: 6 PASS.
- `python3 tools/libretro-profiling/test_validate_q028_renderer_probe.py`: 8 PASS.
- `python3 tools/libretro-profiling/q028_runtime_gate.py ... --reuse`: PASS,
  `INCONCLUSIVE_COMPOSITE`; capture equivalence PASS; exact index forbidden.
- `git diff --check`: PASS.

Reproducible evidence is under
`analysis/evidence/vr60-q028-renderer-descriptor-probe/`. It includes the pinned core/frontend/
fixture, both triplet JSONs per family, 18 result/profile/session/access-ledger sets, lossless A
visuals, callback-capture on/off equivalence ledgers, quarantined DRC-A manifests, and complete
SHA-256 manifests. Large raw pages/state images are deterministically regenerated by the archived
toolchain and immutable fixture.

## Roadmap updates and next research gate

`VR60_STATUS.md`, `VR60_ROADMAP.md`, and the Oracle index now record only the established narrow
facts: A is wheel/tire geometry, B/C have no presented effect in this fixture, the complete player
is composite/unknown, exact-index work is forbidden, and DRC's v4 schedule mismatch is ineligible.
No bridge, authority, cadence, CPU-budget, FPS, or real-hardware conclusion is recorded.

The next gate is research-only: passively trace the surviving player-body pixels backward through
all stock cmd `$02` input families outside the nine `$060024DC` calls and the separate Slave
rendering pipeline, then recover the 68000/FIFO last-writer lineage. Only after that evidence
should a fresh proposal define another reversible all-family visibility experiment. Do not
implement a bridge or reuse A as a body proxy during discovery.

## Auditor Status: REVIEW REQUESTED

Fresh completed-diff review must reproduce the build identities, both static/runtime adversarial
test suites, eligible interpreter suite verdict, evidence hashes, default/prior identity
preservation, permanent exclusions, DRC schedule quarantine, and the exact-index stop.

## Worker update — 2026-09-04 — Q-028 resource pilot launched

Agent: `worker_q028`. This dated update supersedes the historical run instructions/results
above where they conflict with `VR60_STATUS.md` and the newest roadmap correction.

### Task and research

Revalidate the next Q-028 phase-1 prerequisite and execute the existing quarantined resource
pilot if current storage permits. Read `agents/worker.md`, `VR60_STATUS.md`, the current
`VR60_ROADMAP.md`, Q-028 evidence README and v7 contract. Used the codebase-memory skill and
graph tools first to discover/read `q028_phase1_gate.py`, `q028_materialize_picodrive.py`,
`q028_access_v8.validate_pilot`, and `q028_access_v8.deterministic_archive`.

Per `q028_phase1_gate.pilot`, output must be new, outside the repository and `/tmp`, with
240,518,168,576 available bytes before launch. It always builds both source trees below the
pilot root. There is no existing separate-build-root argument. Per
`q028_materialize_picodrive.materialize`, all materialized leaves must preserve Git executable
mode, size, SHA-256 and Git blob identity. Therefore splitting output/source paths would require
a tooling change; neither that change nor a relaxed identity is needed on a qualifying ext4 drive.

### Current prerequisite evidence

- Workspace ext4: 166,806,048,768 available bytes, insufficient.
- `/mnt/audio` fuseblk: 489,163,186,176 available bytes, but prior mode failure still applies.
- `/var/lib/docker` ext4: 257,238,343,680 available bytes, not user-writable.
- Full mount discovery by task manager found `/run/media/matias/Downloads`: user-owned mode
  0700 ext4, 1,545,815,298,048 available bytes. This resolves the storage prerequisite.
- Ordinary ROM SHA-256 is unchanged:
  `6f2768f2cffc85cdc815a67c9f13837112829edac3f0921a57454e79e2523900`.
- Source pack SHA-256 is exactly
  `745cfa19aaca095412fa33e3b402bc471ba70fbe7185328a322325dd06b85c18`.
  Offline verifier passes all 1,633 files, 27,554,071 bytes, six recursive gitlink edges,
  and zero symlinks.
- Immutable 1,340-frame input SHA-256 is exactly
  `2df0ffe53cad0c7d7a5d70c1819051685905a60ff96727a6256e6a300116fbbf`.

### Execution checkpoint

Sandbox escalation accepted the following unchanged production command; no source was edited:

```sh
python3 tools/libretro-profiling/q028_phase1_gate.py producer-pilot \
  --repo-root /mnt/data/src/32x-playground \
  --source-pack /mnt/data/src/32x-playground/tools/libretro-profiling/q028_picodrive_source_pack_v9.tar.gz \
  --manifest /mnt/data/src/32x-playground/tools/libretro-profiling/q028_picodrive_git_closure_v9.json \
  --pilot-root /run/media/matias/Downloads/vr60-q028-resource-pilot-20260904 \
  --frames 1340 --rom-id ordinary \
  --input /mnt/data/src/32x-playground/analysis/evidence/vr60-q028-renderer-descriptor-probe/pre-capture/normal-1p-1340.csv
```

Live execution handle: `2711` (do not restart while live). Both fresh builds already succeeded
and are identical to the August checkpoint: core
`f9e01a81d3bac5926d5f12fcaf1bd055db3702b7fb45f508cf53869234475557` (5,642,416 bytes),
frontend `7883729f53b03b363e5ef1d1cea57efaa5a048283c0a2ea67ab4f50ce6c579ab`
(36,768 bytes). Producer is emitting unfiltered 48-byte access records in 250,000-record chunks.
Metadata shows completed IDL copy with 12,288 reads, 12,288 writes, `bios_null=1`.
At this checkpoint applied input reached frame 101. Completion, validation, archive size, peak
storage, and terminal measurements remain pending. This run is permanently quarantined and
cannot supply a schedule, family outcome, or campaign evidence.

### Roadmap implications and auditor status

Replace the stale storage blocker with the live pilot; retain Q-028's overall blocked schedule
status until its independent required gates pass. A filesystem inventory must include all mounts,
not only `/mnt`. No ROM, hardware, COMM, SH2, ownership, cadence, FPS, gate floor, or source
identity was changed. Ordinary ROM rebuild must wait until the running producer is finished.

NO AUDITOR NEEDED for this existing profiling run; later implementation or acceptance remains
subject to the relevant fresh review.

## Worker update — 2026-09-04 — first pilot terminated; tooling corrections verified

Agent: `worker_q028`. Session `2711` is now **terminal**, not live. A concurrent fresh audit
identified a guaranteed producer/consumer footer-format failure before the pilot could finish:
`agent_counts` keys were emitted in numeric-agent order but `load_canonical()` requires lexical
JSON key order. It also identified the producer RSS measurement's subtraction of cumulative child
high-water marks, which can incorrectly report zero after compiler processes.

At task-manager direction, identified the exact producer PID `1766611`, then sent only that PID
SIGTERM with sandbox escalation. `write_stdin(2711)` confirmed exit 1 and
`command failed (-15)`. This was a deliberate diagnostic termination, not a timeout, resource
limit, or emulation completion. Applied-input prefix ends at frame 443; approximately 7.5 GiB of
raw prefix/build files remain intact in
`/run/media/matias/Downloads/vr60-q028-resource-pilot-20260904`.

### Approved minimal implementation

Task manager relayed the auditor's two blockers and explicitly authorized these host-tool fixes:

- `q028_all_access_observer.inc`: footer iterates the named IDs in lexical agent-name order
  (`10,1,2,3,6,8,4,5,7,9`), preserving every numeric event ID and record ABI.
- `prepare_q028_picodrive.py`: observer identity pin updated to
  `967e0c81c066e09408065ae2734907937ec578cc2f351b6b4bb125c8c952df3a`.
- `q028_phase1_gate.py`: `run()` obtains the exact child's `wait4` resource usage and preserves
  its exit/signal status; producer RSS comes directly from that run result.
- `test_q028_phase1_gate.py`: independent high/low child-memory tests, failed-child exit/log
  preservation, and optional real-core footer producer/consumer regression with reordered-key
  mutation through the unchanged production parser.

No observer access semantics, game source, event IDs, fixture, source pack, reserve/cap/floor,
canonical parser, gate policy, or emulated behavior was changed.

### Verification

`make clean && make all` succeeded after the producer was confirmed terminal. Ordinary ROM still
hashes `6f2768f2cffc85cdc815a67c9f13837112829edac3f0921a57454e79e2523900`.
Two clean offline builds via existing `build-pair` succeeded under
`/tmp/vr60-q028-footer-fix-build-20260904`. Both cores are
`67c93765b3fd9a2b6c2d0941b1afdec2d4d4a7841a43a1e1a8507cb5b784c7d9`
(5,642,456 bytes); both frontends remain
`7883729f53b03b363e5ef1d1cea57efaa5a048283c0a2ea67ab4f50ce6c579ab`
(36,768 bytes). Their full build/postimage/resource report is `clean-build-pair-v9.json`.

All three regression methods pass with:

```sh
env Q028_TEST_CORE=/tmp/vr60-q028-footer-fix-build-20260904/build-a/source/picodrive_libretro.so \
    Q028_TEST_FRONTEND=/tmp/vr60-q028-footer-fix-build-20260904/build-a/profiling_frontend \
    python3 tools/libretro-profiling/test_q028_phase1_gate.py -v
```

The short real-core diagnostic uses exactly the first six input rows, runs six frames, reaches
the 12,288-read/write IDL copy, and produces a footer accepted byte-for-byte by production
`load_canonical()`. Reversing only its nested agent-key order is rejected. This is a serializer
regression, never a resource-pilot PASS or eligible campaign result. Initial smoke setup supplied
the full fixture to six requested frames and was rejected before emulation; inspecting the
frontend's exact-row loader established the required diagnostic prefix.

`git diff --check` passes. A fresh completed-diff auditor must approve these corrections before
another full resource pilot. Original source pack and immutable fixture stay exact; the aborted
first run must not be reused as a completed pilot.

AUDITOR REVIEW REQUESTED

## Worker update — 2026-09-04 — audited corrected resource pilot live

Task manager relayed fresh Auditor APPROVED for the two tooling corrections and confirmed
static/runtime tests plus the final ordinary clean rebuild passed. Launch rechecked ordinary ROM
`6f2768f2…2523900`, source pack `745cfa19…dd06b85c18`, observer `967e0c81…52df3a`, and phase-1
gate `88c77eb3…52677` against the reviewed files. Downloads ext4 had 1,537,810,849,792 available
bytes, above the unchanged launch floor.

The corrected full 1,340-frame ordinary-ROM resource pilot was launched with approved sandbox
escalation, using the exact prior command with only the new root
`/run/media/matias/Downloads/vr60-q028-resource-pilot-20260904-r2`.
**Live session: `61766`.** This session supersedes terminal first-attempt session `2711`.
No source edits or ordinary rebuilds may occur during this producer. Poll this same handle;
observation timeout does not authorize restarting. All output remains resource-only quarantine.
Build, production completion, validator, archive, and terminal measurements are pending.

NO AUDITOR NEEDED for the approved existing profiling execution.

## Worker analysis — 2026-09-04 — downstream integration prerequisites (read-only)

These are current source facts, independent of the running r2 pilot's eventual outcome.
Graph discovery was attempted and returned `Transport closed`; targeted source reads followed.
No downstream source or contract was changed.

1. `tools/libretro-profiling/q028_runtime_gate.py:65` still sends INTERPRETER access output to
   `target/access.csv`. The v8 observer treats that value as a directory and opens metadata,
   chunk, and footer children under it (`q028_all_access_observer.inc:874`). The launcher creates
   only capture/video/terminal subdirectories (`q028_runtime_gate.py:50`), so this path is not
   compatible with the current observer. Fix by explicitly creating/naming a v8 access directory
   and binding its complete file set to package validation; never reinterpret missing logs as
   successful observation.
2. `tools/libretro-profiling/validate_q028_renderer_probe.py:52` currently validates only the
   display/input/state package through line 144; it has no import/call of `q028_access_v8`, no
   binary chunk consumption, and no access-footer check. The new parser currently applies only
   to the quarantined ordinary pilot. A reviewed campaign integration must compose complete
   v8 event/IDL/footer/agent coverage with the existing family/context/ledger predicates.
3. The same production validator still fixes pre-FS frames to `1298,1301,1304` at line 105,
   requires FEN zero at line 108, and fixes command 54 to frame 1300 at line 134. It has no
   reviewed-schedule argument. `q028_runtime_gate.matrix` does compare each run's metadata with
   the reviewed frozen engine at lines 93 onward, but that does not replace the standalone
   validator's stale engine-independent predicates. A correction must bind validation to the
   prospective audited engine schedule, preserve the fixed input/window and structural temporal
   invariants, and reject altered schedule hashes. It must never infer one engine from another.
4. `tools/libretro-profiling/q028_evidence.py:181` pins four archives to 1,073,741,824 compressed
   bytes total and 17,179,869,184 uncompressed bytes total, matching v7 contract JSON. The pilot's
   unfiltered access ABI allows up to 72,000,000,000 record bytes for one run; actual resource
   measurement is still pending. A separate explicit proposal must derive campaign resource
   bounds from validated measurements while preserving all 40 complete raw packages, required
   visual/state members, source identities, unfiltered access meaning, deterministic archive
   security checks, and permanent quarantine of pilot outcomes. Do not quietly change these caps
   or discard raw members to meet them.

After a successful pilot, propose and freshly audit one complete v8 launcher/validator/archive
integration, then run the four fresh capture-off schedules, independent schedule audit, and the
36 capture-on matrix. This is necessary evidence repair within Q-028, not a family/bridge or
FPS claim. Current analysis does not authorize source or policy edits during the producer.

AUDITOR REVIEW REQUESTED for the future concrete integration proposal; no new code implemented.

## Worker update — 2026-09-04 — r2 terminal validation failure

Session `61766` is **terminal exit 1**, reporting `Q-028 Phase-1 gate FAILED: fetch slot`.
The deliberate stop escalation was interrupted while pending; no SIGTERM delivery was confirmed.
The producer completed all 1,340 frames naturally while that request was pending, then the
production reader rejected record zero. Exact producer PID recheck returned absent before the
terminal handle poll. Do not describe this r2 run as terminated by us or still live.

All r2 output remains intact (approximately 23 GiB). The canonical terminal footer reports
496,577,712 events in 1,987 chunks, `frames=1340`, `reason=core_deinit`, zero dropped/unknown,
`resource_limit=false`, but **1,212 errors and 63,806,555 unattributed events**. These are
producer claims pending full raw recomputation, not a passing resource result. Applied input
has the exact immutable full-fixture hash. Footer SHA-256 is
`be0946668f0f8013f064dfe606af3f5bff1b53b2aca1ea309e7159587ad46cc4`.

A read-only diagnostic copied only the already-closed first 12,000,064-byte chunk to
`/tmp/q028-closed-chunk-oaxY0t`. Both original and copy SHA-256 are
`1346194903781de3f7f8519db8163862518ffbc113b9092783c80f15be2fda38`. Feeding this unchanged copy
and the pinned canonical static map to `q028_access_v8.read_events()` rejects `fetch slot` at
line 121. Sequence zero is cpu0/frame0/PC `$3F0`, fetch flags25, width6, site1373, slot0.
`vrd_q028_event` zeroes the record but never assigns the fetch sentinel; assigning the local
variable `slot=0xffff` does not initialize the packed field. Data paths alone set the field.

Further bounded research before any patch is required: SH2 reset reads at PC0 precede a fetch
context; PicoDrive generates a builtin BIOS image when BIOS inputs are null, absent from the
ordinary-ROM site domain; the footer reports `master_dreq0` with 47,038 hook entries and
188,152 records despite the pilot inventory describing that agent N/A. Full retained raw
diagnostics are being classified against source and the primary reset manual before proposing
the complete minimal ABI/domain fix. No parser relaxation, captured-byte correction, or
production code change has been made.

AUDITOR REVIEW REQUESTED after the complete evidence-backed proposal.

## Worker update — 2026-09-04 — full raw diagnostic terminal and repair WIP

The complete read-only native scanner session `83569` is now terminal **exit 0**.
It scanned all 1,987 original chunks / 496,577,712 consecutive events and independently counted
63,806,555 unattributed records. M68K/Master/Slave malformed fetch-slot counts are respectively
3,992,724 / 88,399,779 / 247,893,438. The only context-slot mismatches are the two reset reads
per SH2; M68K has zero and there are no later SH2 mismatches. Original r2 artifacts are unchanged.
The complete 4,054-group CSV is `/tmp/q028-r2-unattributed.csv`, SHA-256
`26cc17f2883992dae06d87cddf67dc62c9ef9802b006a9c9491b9ff2d91c242b`.
No producer or scanner is live.

The full aggregate closes SH2 missing PCs to builtin BIOS or on-chip SRAM: Master BIOS 196,625
records, Master SRAM 27,563,116; Slave BIOS 60, Slave SRAM 34,842,117. SRAM first appears at
frame 398 on both CPUs, so a six-frame boot regression alone cannot cover this domain. M68K
BIOS contributes 11 records. Additional M68K source-backed analysis remains required: there
are 256 distinct linked raw-instruction starts beyond the initially approved eight islands,
including the unrolled `$0188EC-$0189EC` MOVE.W/RTS code and raw branch/JSR/LEA starts in game
and sound modules. The classifier is `/tmp/q028-domain-classify.py`; it uses the full aggregate
and exact byte-matched listing only for diagnosis, never to create an acceptance allowlist.

M68K word differences beginning at frame 360 are source-proven emulator idle-detector rewrites:
`cpu/fame/famec_opcodes.h:40300` computes fake branch opcodes, calls `SekRegisterIdlePatch`, then
writes `PC[-1]`; `cpu/fame/famec.c:4982-5007` explicitly maps those fake opcodes back to the
corresponding normal/idle branch handlers. `pico/sek.c:SekFinishIdleDet` restores them by direct
host writes. Preserve these actual fetched words and model an ordered source-bound host-rewrite
ledger; do not disable detection or normalize raw events. This needs a fresh amendment together
with mutable WRAM trampoline provenance (scene pointer at FF0002 and V-INT immediate at FF0008).

Auditor approved proposal `1dd62401e73854afa7d1c93bd288b5c32eae77d5f1a338bad700bbdc169ce9fa`
for implementation only. Approved independent work is **in progress**, not fully integrated:

- New `q028_image_domains.py`: pinned Binutils 2.46 M68000 decoder, finite raw islands, source-pack-
  bound BIOS recipe, exact SRAM loop/literal/payload verification and finite candidate views.
- `q028_owner_analysis.py`: listing continuation bytes, approved sound starts/islands, image-view
  site identity and helper dependency manifest. Full linked listing independently decoded to
  22,204 instruction starts; auxiliary recipe yields 2,064 BIOS/SRAM candidates.
- `q028_all_access_observer.inc` / `prepare_q028_picodrive.py`: fetch sentinel, strict boot reset
  slots, BIOS snapshot hook, CPU-local SRAM installation tracking, passive original-sequence
  COMM facts replacing guessed submit/ack state. Numeric packed ABI remains unchanged.
- New `q028_image_state.py` and `q028_access_v8.py`: independent reset/SRAM/COMM reconstruction,
  actual ROM/analyzer/header identity join, reserved flag rejection and agent-key/N/A checks.
- `q028_phase1_gate.py`: source-proven Master DREQ0 applicability.
- New `test_q028_image_domains.py`: seven source-derived tests pass, covering exact BIOS images,
  decoder truncation, source-array parser rejection, reset order, private SRAM installs and
  invalidation/view collisions, width-aware passive COMM facts and non-idle terminal state.

Verification: `PYTHONPATH=tools/libretro-profiling python3 -m unittest -v test_q028_image_domains`
passed all 7 tests without skips. A negative truncation test exposed objdump's stop-address byte
display truncation; decoding a ten-byte lookahead now checks the full last instruction before
the reviewed range end, and the malformed boundary is rejected. Python compile/diff checks pass.
`make clean && make all` session `95464` exited 0; ordinary ROM remains
`6f2768f2cffc85cdc815a67c9f13837112829edac3f0921a57454e79e2523900`.

Remaining: additional finite raw-domain and mutable/host-rewrite provenance amendment; finish
full toolchain dependency joins, complete-stream/terminal validation and adversarial actual-
artifact tests; regenerate site artifacts and update reviewed overlay pins; two clean core
builds; six-frame all-binary plus predeclared later-domain real-core regression with command
logging enabled and zero skips; fresh completed-diff Auditor approval. Current generated maps
and overlay pins are deliberately not yet promoted, so a new core build/full pilot is not ready.
Existing fixed caps, quarantine, all prior ROM identities and the Q-028 gate remain unchanged.

AUDITOR REVIEW REQUESTED for the additional source-domain amendment; approved repair WIP is not a pilot PASS.

### Follow-up — approved integration pass, source admission still held

The aggregate, exact native source and executable are now durably retained under
`analysis/evidence/vr60-q028-renderer-descriptor-probe/diagnostics/r2-full-raw-scan/`.
CSV/source/executable SHA-256 values are respectively `26cc17f2...91c242b`,
`66cb855e4ebfcc05120a863d7bf0330d1381ec71678996cd4a581ac26fedb699`, and
`db4ed00f3fa02392da7b05e7c4e3c89465fbd61d4dc5707b70c3ee65fd2b2a53`.

The current approved implementation additionally snapshots all actual host-tool build inputs,
joins both clean core/frontend outputs and exact overlay postimage sets to actual files, and
rejects false/missing imported-helper identities. Finalization independently closes streams,
accounts semantic errors before serializing footer counters, and emits a final process-log
error marker so footer-close failures cannot hide behind an earlier serialized zero counter.
The reader now checks passive COMM fact CSV bijection/footer state, including consistent
source-proven bootstrap route and width-aware overlapping lane effects.

`test_q028_phase1_gate.py` now enables the command-log path in the real-core smoke and calls
the production binary reader/IDL validator over every emitted chunk, checks exact footer/CPU/
COMM counters and zero error/loss/open context, and deterministically mutates copies of actual
new output (slot, reserved flags/byte, opcode word and all-chunk wrong prefixes). This updated
real-core test has **not** been run: new generated sites/overlay pins and clean cores are still
held until the additional source-domain amendment is approved. A plain skipped test is not
accepted evidence. The two explicit child-resource tests pass separately without skips.

The mutable/host-rewrite proposal is `q028-mutable-images-amendment.md`, SHA-256
`f367bde6facfc64e24b66b55fa10ac98379c6838289ededc7c7c4e8a0a48806b`.
It does not authorize itself: complete finite raw-island/table-boundary inventory and fresh
Auditor approval remain required. Parent independently proved bogus linked instruction/table
boundaries at C7E8 and 9F16; these must be source-corrected byte-identically under that explicit
amendment, not accepted as overlapping true instructions. No such source correction or mutable/
idle-rewrite admission is implemented in this WIP.

AUDITOR REVIEW REQUESTED for the completed additional-domain amendment; no full pilot authorized.

### Combined amendment attachment — 2026-09-04

The finite source inventory is now attached to `q028-mutable-images-amendment.md`.
Combined amendment SHA-256: `171a862a878213c4175b938a9376330f17fbd7d515c93dd686ccf4777d4c48d2`.
Its inventory is the durable `q028-m68k-finite-inventory.json`, SHA-256
`a09955793f72928a4c9133672aa9c7d2319c6e21d4933981a138afffb70edee8`.
An independent byte/hash check passed all 321 instruction identities, 120 finite spans and
five exclusions against the accepted ordinary ROM. The three historical bad boundaries at
9F14, C7E6 and 8200 are explicitly rejected in favor of the exact true instruction/extension
boundaries. Only byte-identical assembly presentation corrections are proposed; no game code
behavior, linked byte, admission rule or overlay identity has been changed for this amendment.

AUDITOR REVIEW REQUESTED for this combined design before additional implementation.

### Approved amendment and first implementation stage — 2026-09-04

Fresh Auditor approved implementation only for the revised mutable/host-rewrite amendment
`d230ca49c6572aba83d267aa0667c431cccd9c386e3ec7762a07c4efb924f772`, together with
finite inventory `a09955793f72928a4c9133672aa9c7d2319c6e21d4933981a138afffb70edee8`.
Parent explicitly authorized that exact scope. Boot copy metadata excludes its final 12 data
bytes; host installs bind to the immediately preceding original branch fetch; restore callbacks
follow the complete source expression; EOF ledger boundaries are consumed without fake events.

Implemented the three approved source-presentation corrections and finite inventory/source/ROM
identity checks plus analyzer data/extension exclusions and finite-span decoding. Clean build
session 14552 exited 0; `/tmp/q028-finite-presentation-build.log` is retained. The ordinary ROM
still hashes to `6f2768f2cffc85cdc815a67c9f13837112829edac3f0921a57454e79e2523900`.
No new core has been built or captured. Mutable WRAM and host-ledger implementation, actual
all-binary six-frame and beyond-frame-398 regressions, adversarial artifacts, two reproducible
core builds, all prior/probe identity checks and fresh completed-diff audit remain required.

AUDITOR REVIEW REQUESTED after completed implementation/tests; design approval is not pilot approval.

### Implemented ledger and first new-core stream — 2026-09-04

Finite listing check 77628 exited 0: 22,464 M68000 rows / 1,296 sources. The attached 321
instructions tile all 120 spans; source/data exclusions and all three postimages are checked.
`q028_image_domains.py` now generates separate WRAM views with exact copy/code boundaries,
mutable masks and finite FAME handler aliases. `q028_image_state.py` reconstructs copy/mutable
bytes and ordered host writes independently; the C observer checks host RAM against its own
state and emits successful source-bound install/restore callbacks. The raw packed ABI is unchanged.
Twelve standalone image/domain tests pass, zero skips. Parent independently compared 223 valid
C/Python WRAM transitions and five malformed copy cases; this is not actual-core acceptance.

Generated, unpromoted map: `/tmp/q028-v10-sites-45hm_7e8/`, 1,594,180 sites, include SHA-256
`6ab86f19c791a0856ed5f89977b89f63ca2a55ed8d5e9132ac4c42c73c77502f`.
Canonical pre-capture JSON is unchanged. Probe ROM build 31732 exited 0/static verifier PASS;
ordinary SHA remains accepted. All new dependency inputs are retained by build-pair snapshots.

First core pair 8822 failed compilation because libretro maps `fprintf` to `rfprintf(RFILE*)`;
its new terminal marker incorrectly passed libc stderr. Source header proved that mismatch.
Changed only the process marker to `dprintf(2,...)`; failed build retained in
`/tmp/q028-v10-repair-build-pair/`. Corrected pair 51679 exited 0 in
`/tmp/q028-v10-repair-build-pair-r2/`; both cores are 6,708,912 bytes, SHA-256
`b3bd2d5551e7f6152e6c71a1057cd8619039f68084d323b3b4419ecfaceb69b7`.
Frontend SHA remains `7883729f53b03b363e5ef1d1cea57efaa5a048283c0a2ea67ab4f50ce6c579ab`.
Core-build child peaks are 440,492,032 and 440,549,376 bytes. Actual tool/snapshot/postimage/
binary identity joins pass. No build process remains live.

Real six-frame test 74808 terminated FAILED at the independent IDL validator, after production
`read_events` consumed all 517,467 events and producer footer reported errors/unknown/dropped/
unattributed all zero. Raw artifacts are retained unchanged in `/tmp/q028-v10-smoke-r2/`.
No PASS receipt was emitted. Validator hardcodes (02000200,06000200), but the accepted ROM
header at 3D4/3D8/3DC is (00020000,00000000,0000C000). Pinned `pico/32x/32x.c:202–211`
derives (02020000,06000000), exactly matching raw first/last pairs. All 12,288 ordered longword
pairs and target coverage 74/74 passed. Sent this exact source-backed predicate correction for
Auditor review before editing it. No normalization or raw modification is proposed.

Host-ledger review is pending with a fresh Auditor. Actual-artifact mutation cases and the
400-frame later-domain regression remain unrun; no full pilot is authorized. Parent requested
and Worker implemented test receipt emission only after all positive assertions, with a separate
mutation receipt and explicit agent count joins. That harness revision has not yet been rerun.

AUDITOR REVIEW REQUESTED for the concrete IDL correction and completed host-ledger subsystem.

### User-requested checkpoint freeze — 2026-09-04

Auditor/parent approved deriving IDL bases and extent from the hash-bound accepted ROM header,
including an additional fail-closed comparison of each read value with the corresponding ROM
bytes. Implemented both without changing pair order/value/width/normalization or 74/74 coverage
checks. The reader now rejects an invalid footer frame count (must be an integer in 1..1340)
and rejects any raw event at or beyond its declared terminal frame. EOF host restorations may
still equal the terminal frame; no synthetic event is created.

Before those final value/frame assertions, fresh real six-frame session 64852 completed PASS:
one test, zero skips, 32.846 seconds, all 517,467 binary events and complete IDL/COMM/empty-host-
ledger checks, plus six deterministic actual-artifact mutations. Original capture, mutated
copies, positive stream receipt and separate mutation receipt are retained at
`/tmp/q028-v10-smoke-r3/`. The earlier failed `/tmp/q028-v10-smoke-r2/` is unchanged.
This six-frame run cannot cover frame-360 idle rewrites or frame-398 SRAM execution.

After the final narrow corrections, 16 focused standalone tests pass without skips, including
all source-IDL/header/base/extent/value mutations and terminal-bound validation. A bounded
read-only replay over unchanged smoke-r3 checked all 24,576 IDL transactions against actual ROM
bytes and all 517,467 event frames against terminal 6. The newly added actual-artifact terminal-
frame mutation has not been run through the full real-core test; neither has the expanded host-
ledger/finite-domain actual-artifact mutation matrix or the 400-frame regression.

Checkpoint is deliberately non-promotable WIP. Canonical pre-capture JSON remains older than
the unpromoted generated include/map. Pair-r2's compiled observer identities remain unchanged,
but its tool snapshot predates the final reader changes and must be refreshed before final
toolchain acceptance. No full pilot, family/schedule campaign, or Q-028 PASS is authorized.
Parent is preparing the requested checkpoint commit; Worker will pause all edits/builds after
the final coordinated clean ordinary build terminates. No captures will start during the freeze.

AUDITOR REVIEW REQUESTED after remaining runtime/mutation coverage and refreshed final closure.
