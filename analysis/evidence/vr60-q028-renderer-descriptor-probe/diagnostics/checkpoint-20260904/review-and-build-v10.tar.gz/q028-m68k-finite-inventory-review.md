# Q-028 finite M68000 source inventory — amendment attachment

PROPOSED ONLY, 2026-09-04. This is an implementation-review input, not a
runtime admission or acceptance result. Read together with
`q028-mutable-images-amendment.md` and approved repair `1dd62401…69ce9fa`.

## Exact inventory and evidence boundary

`analysis/evidence/vr60-q028-renderer-descriptor-probe/diagnostics/r2-full-raw-scan/q028-m68k-finite-inventory.json`
SHA-256 `a09955793f72928a4c9133672aa9c7d2319c6e21d4933981a138afffb70edee8`
contains 321 independently decoded instructions in 120 finite half-open file
spans, exact bytes and instruction/span hashes, source filenames/rows/file
hashes, and the ROM/listing/decoder identities. It includes all 256 starts
located by the diagnostic aggregate and 65 additional source-defined sibling
instructions. Neither the aggregate's PCs nor its counts become an admission
rule. Runtime data located the omissions; the linked bytes, annotated source
instructions, direct call targets, and complete dispatch blocks define the
proposed static candidates.

The ordinary ROM is unchanged, SHA-256
`6f2768f2cffc85cdc815a67c9f13837112829edac3f0921a57454e79e2523900`.
Every span tiles completely under the reviewed M68000 decoder, with exact
linked bytes, no truncated instruction, and no illegal-word fallback. VASM
`dc.w` continuation rows must be assembled into the full instruction; the
first listing word alone is not its size. Most isolated spans are explicit
BSR/Bcc/JSR/LEA instructions in named function bodies, with source comments
and neighboring mnemonic control flow. All such annotated raw instructions
in those specific source modules are included, not just executed siblings.
This is finite conservative instruction attribution, not a global proof of
executability, ownership, or immutability.

## Source-defined blocks, not arbitrary numeric windows

- `[0021EE,002200)`: `sections/code_200.asm` explicitly starts
  `counter_increment_flag_set`; two MOVE.B immediates, TST.W, BEQ.S continue
  into `code_2200.asm`. The call at `race_scene_init_004a32.asm:004C66`
  independently targets 21EE.
- `[0081D8,008202)`: calls at file 005B40, 005CC0, and 005D58 target 81D8.
  BTST/BEQ then the exact straight-line instructions end with
  `CMPI.B #$BE,$C8A4.w` at 81FC (six bytes). The branch targets 820A;
  fallthrough resumes at the existing BEQ.S at 8202. See the section-edge
  correction below.
- `[00A1FC,00A200)`: MOVE.W `$C8CA.w,D0`, reached by direct JSRs at 004B7C
  and 0054B2. The function continues in the next section's mnemonics.
- `[00CC72,00CC74)`: source-identified RTS stub, directly called at 0054C6.
- `[00E206,00E20A)`: annotated DBRA D3,E1CA continuing the palette loop
  across the section boundary, followed by RTS at E20A.
- `[012A40,012A46)`: source explicitly distinguishes three 16-word DATA
  tables `[129E0,12A40)` from `fn_12200_023_dispatch`; this JSR consists of
  `dc.w $4EB9` plus its linked `dc.l` address 00882080.
- `[0188EC,0189EE)`: exactly 128 `MOVE.W (A1)+,(A2)` words (3499), then
  RTS (4E75). `mars_dma_xfer_vdp_fill.asm` emits nine JSRs and a final JMP
  to 008988EC, streaming ten blocks from FF6000 into MARS_FIFO. The caller
  entries are file 002900,002906,...,002936. The following 8A8A data is
  excluded; a two-byte sampled-only window is not the block definition.
- `[00BC1C,00BC30)`: all five BRA.W entries of `scene_command_disp`, used
  by its indexed JSR at BC82. The following pointer table is DATA, not
  more branch entries.
- `[0305C4,030604)`: all 16 BRA.W entries following the indexed JMP at
  305C0 in `fm_system_command_disp`.
- `[03109E,03111A)`: all **31** BRA.W entries after the indexed JMP at
  3109A; byte counts contradict the older header's “32-entry” wording.
  The next code starts at 3111A. `[031124,031144)` contains all eight
  BRA.W entries of its secondary indexed JMP at 31120. The finite byte
  bounds, not historical comments about entry counts, govern the map.

## Required table/extension exclusions and source corrections

1. `race_start_countdown_sequence.asm`: the dispatcher at 9EC0/9EC4/9EC8
   reads the 19-longword pointer table `[009ECA,009F16)`. Its second entry,
   at 9ECE, is 00889F16. The real instruction `[009F16,009F1A)` is
   `CLR.W $90B0.w` (4278 90B0). The current false MOVE.W at 9F14 swallows
   the first real opcode. Represent the table as DATA and the CLR.W as
   code; exclude all old mnemonic candidates in the table and the overlap.
2. `track_graphics_and_sound_loader.asm`: `[00C7C2,00C7E0)` is its declared
   animation data prefix; `[00C7E0,00C7E8)` is the four-word timing table
   003A,0050,0064,0083. `race_scene_data_loader.asm` at C7A4 stores
   0088C7E0 as the table pointer. `hardware_init.asm` at D4C directly calls
   0088C7E8. The real `[00C7E8,00C7EE)` is `LEA $0089AF3C,A0`; the
   existing ORI.L at C7E6 incorrectly straddles table/code. Exclude the
   complete `[00C7C2,00C7E8)` data and overlapping old instruction row.
3. `display_state_timer_flag_update.asm`: the source's first word at
   008200 (C8A4) is the address extension of CMPI.B at 81FC, **not** an
   independent AND.L instruction. Exclude `[008200,008202)` as a start;
   represent the cross-section instruction faithfully and correct the
   misleading function comment. Keep every linked ROM byte unchanged.
4. `scene_command_disp.asm`: `[00BC30,00BC40)` contains four longword
   pointers read at BCA6, not executable EOR/CMPA instructions.
5. `psg_freq_table_special_command_disp.asm`: `[030FE0,031094)` is the
   frequency DATA prefix, regardless of its misleading mnemonic rendering.
   Its byte length is 180, not the older header's claimed 128 words.
   Real SUBI.W code begins at 31094; do not decode the prefix as code.

The inventory retains all five exclusion byte ranges and hashes (the first
two table regions are combined where contiguous). Source-presentation edits
are allowed only with unchanged linked bytes and clean rebuild comparison;
there is no permission to change game instructions or behavior. Source
hashes in the attachment identify the pre-correction evidence: after those
edits, retain old/new source hashes plus identical ROM/span byte checks.

Fail closed on any span hash mismatch, wrong decode width, overlapping
instruction start, extension-as-start, or data-table candidate. Test the
three precise bad historical starts 9F14, C7E6, and 8200 and neighboring
valid entries. A source row cannot be admitted merely because its text is
a mnemonic, and known DATA exclusions take precedence over generic listing
parsing. These exclusions do not claim every unrelated table is classified.

## Review and runtime gate

No ROM behavior change, broad `dc.w` decoding, runtime-PC allowlist, or
changed observer acceptance tolerance is proposed. The mutable WRAM and
FAME host-rewrite domains require their separate ordered state models in
the companion amendment. This attachment alone cannot make a fake FAME
opcode or modified RAM operand match an immutable source instruction.

Require fresh Auditor approval of the combined design before admission
implementation, then actual new-core artifact/mutation tests through at
least frame 398, reproducible core builds, unchanged ordinary/probe ROM
identities, and a fresh completed-diff review before another full pilot.
