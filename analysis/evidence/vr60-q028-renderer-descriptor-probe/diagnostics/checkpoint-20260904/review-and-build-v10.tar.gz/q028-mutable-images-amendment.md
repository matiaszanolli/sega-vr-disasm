# Q-028 mutable instruction-image amendment — 2026-09-04

PROPOSED ONLY. Complements approved repair `1dd62401...69ce9fa`; no admission code for
these additional domains has been implemented. The finite source inventory is now attached
below. The combined design still requires fresh Auditor approval before implementation.

## Why exact linked-byte identity is not sufficient

The original map aliases both file F92 (`4EB900894262`) and FAA (`4EB900884CBC`) to
M68K FF0000. They share the first opcode but not the full instruction. The normal template's
MOVE.W at file F98 maps to FF0006; its immediate at FF0008 is intentionally rewritten.
These are real mutable game instructions, not SRAM-style immutable copied payloads.

Separately, pinned `cpu/fame/famec_opcodes.h:40300-40337` rewrites short backward branches
in host memory after `SekRegisterIdlePatch` accepts a patch. `cpu/fame/famec.c:4982-5007`
installs the exact handler aliases for these fake opcodes; `pico/sek.c:SekFinishIdleDet`
restores them with direct host writes. Detection begins after 360 frames. The completed
raw aggregate contains these fake words beginning at frame 360, including FF0014=73F6.
They are not legal new M68000 instructions and must never be decoded/labeled as such.

## Fixed boundary

No ROM byte changes, no idle-detector disable, no raw normalization, no extra emulated reads/writes,
no changed timing/handler behavior, and no new CPU/agent IDs or packed-record fields. Preserve
the binary stream's actual fetched word and every original emulated write. Keep static
analysis conservative for mutable operands; no global negative ownership claim follows.
Only the byte-identical assembly presentation corrections described in section 4 are proposed;
they may change source text and source hashes, never linked instructions, data, or game behavior.

## 1. Finite WRAM template installs

Source-bound templates, all destination FF0000, with original linked bytes retained in the map:

| Template | Source reads | Exact copy instruction PCs | Length |
|---|---|---|---|
| Adapter boot | 000004C0 + stride | file 04A8,04AA,...04B6; opcode22D8 | 8 longwords / 32 bytes |
| Normal dispatch | 00880F92 + stride | 00880FDE; opcode32D8 | 12 words / 24 bytes |
| Alternate dispatch | 00880FAA + stride | 00880FDE; opcode32D8 | 10 words / 20 bytes |

The adapter copies 32 bytes but only `[0004C0,0004D4)` is executable: four instructions
at file 04C0, 04C6, 04CC and 04D2, mapping to WRAM FF0000, FF0006, FF000C and FF0012.
The remaining `[0004D4,0004E0)` is VDP table DATA, copied to `[FF0014,FF0020)`.
Boot-template metadata must distinguish `copy_size=32`, `code_size=20`, allowed start offsets
`[0,6,12,18]`, and copied-data offsets `[20,32)`. Completing all 32 copy bytes does not admit
a fetch from the final 12 bytes. Reject every boot-view fetch at FF0014..FF001F, even if its
word could decode as an instruction; later normal/alternate views use their own boundaries.

Linked listing lines2329-2334 define normal JSR/MOVE/STOP/TST/BNE/BRA. Normal setup at0FBE
loads D7=11; 0FC0 PC-relative LEA resolves00880F92. Alternate setup0FCE loads D7=9;
0FD0 LEA resolves00880FAA. Both use DBRA at0FE0, with2700 mask at0FDA and2300 restoration
at0FE4. Each source-read/destination-write pair has the same MOVE instruction PC.
The source-only additional boot variant at0894/copy PCs087C..088A is excluded until a
separate source/range review and diagnostic use check establish its necessity.

Producer and reader independently observe complete ordered copy pairs, exact original CPU,
source/destination/stride/width/value/PC/count. A recognized first read invalidates the prior
view; only the complete matching copy activates the new view. An interrupted or mismatched
install cannot create a partial executable identity. Other-CPU events may interleave.

After a complete normal install, only FF0002..FF0005 (JSR address) and FF0008..FF0009
(MOVE immediate) are explicitly mutable. Alternate install allows FF0002..FF0005 only.
The boot template has no proposed mutable extension fields. Every real write overlapping a
mutable field updates its byte state using original big-endian width/lane semantics; no value
allowlist is inferred from a failed run. An overlapping write touching any non-mutable byte
invalidates the template unless it is a recognized complete reinstall or the separately
observed host rewrite below. Scratch beyond the selected template extent is unaffected.

## 2. Honest template identity in the unchanged record

Rows for mutable-template instructions explicitly declare `opcode_identity_kind=masked-template`,
the source template image/view, full instruction width, immutable byte mask, initial linked
bytes, and mutable byte ranges. Their static `opcode_hash32` is the SHA256-prefix of the
masked template bytes, **not a claim about the current full instruction bytes**. All attached
memory operands are dynamic and retain their runtime events. Immutable-template instructions
keep exact-byte hashes. Row classification must make this distinction visible in all reports.

At each WRAM fetch the observer compares the actual direct host WRAM bytes (no emulated read
callback) against the independently maintained current template byte state, verifies all
immutable bytes, and emits the actual first opcode word plus the selected template identity.
The reader reconstructs the same bytes from the complete install and subsequent original raw
writes. It verifies the current instruction boundary, mask, template/view, actual first word,
and every write's lane update. No inferred linked extension is presented as an observed value.
The actual mutable bytes and their source sequence IDs remain recoverable from the raw stream;
the template hash does not replace that provenance. Missing writes/copies, wrong CPU, stale
view, wrong mask, or unknown fixed-byte modifications fail closed.

This is an explicit metadata meaning amendment for a narrowly classified instruction family;
it is not a generic relaxation of exact opcode identity for ROM/BIOS/SRAM sites.

## 3. Ordered host-rewrite ledger

Add a validation-only callback immediately **after** the successful `PC[-1]=newop` assignment
in FAME's `idle_detector_bcc8`, and after each actual restoration write in `SekFinishIdleDet`.
For restoration, capture the old word before the source expression and invoke the callback
only after the **complete** `*op &= 0xff, *op |= real_base` expression has finished, never
between its two assignments. The observed replacement is the final restored word, not the
temporary masked intermediate. Preserve the original source expression and its ordering.
Preserve every original assignment, return value, branch and cycle operation. A compact
host-ledger CSV records monotonically increasing ledger ordinal, next binary sequence ID,
frame, main-68K guest PC, original word, replacement word, operation `install`/`restore`,
and the pinned source-site identifier. Host addresses/pointers are never serialized; an internal
pointer→guest-PC map from successful installs identifies later restore targets. Rejected patch
registration/no-write outcomes must not fabricate a write record. Secondary 68K behavior is
outside this exact cartridge fixture and must fail if it unexpectedly reaches this ledger.

Source-derived accepted install pairs are only the ten real opcodes in `INSTALL_IDLE`:
66FA/66F8/66F6/66F2,67FA/67F8/67F6/67F2,60FE/60FC. For each, compute the fake word using
the exact source formula `(real&0xFE)|0x7100`, optional0200 for the non-idle handler,
0400 for BEQ, and0C00 for BRA. Both possible outcomes preserve the handler identity recorded
by the source; neither is treated as an arbitrary legal M68000 decode. Static rows exist only
for those finite original branch starts in reviewed ROM/WRAM images. Record the original
semantic branch operation and distinct `engine-idle-rewrite` image identity alongside actual
fake bytes. Restore pairs follow the exact three source masks and must agree with current
byte state. An unrelated word or PC is not admitted by matching a high-byte pattern alone.

The reader merges ledger entries by their `before_sequence` boundary before consuming that
binary event. It verifies contiguous ledger ordinals, nondecreasing boundaries, exact old/new
word and image transition, no gap/duplicate/late application, and source/current-image binding.
An `install` row must bind to the immediately preceding original raw branch fetch that invokes
the detector: `before_sequence == triggering_fetch.sequence + 1`, with identical frame,
main-68K CPU, guest PC and original real branch word. That preceding raw event must be a fetch,
not a data access, other-CPU event or earlier occurrence of the same branch. Pinned
`SekIsIdleCode`/`SekRegisterIdlePatch` make no intervening emulated bus access on this path.
The observer records the actual detector boundary; the reader independently enforces this
exact trigger relation. Merely matching a nondecreasing boundary and current bytes is not
sufficient. A `restore` is a separately source-bound teardown host action and must never be
assigned a fabricated preceding CPU fetch to satisfy the install rule.
A patched fetch without a preceding install fails. An install whose old word differs from
the current source/template state fails. Emulated raw writes to a WRAM branch update/invalidate
that state as above; a later restore cannot assume a stale original branch. Any source restore
that genuinely rewrites a changed target must be modeled exactly and researched if it falls
outside these finite pairs, not silently repaired.

At terminal, flush/close the ledger independently, retain count/last ordinal/last boundary,
and compare them to recomputed observer metadata. After consuming the last raw event, explicitly
apply and reconcile every ledger row whose `before_sequence == final event_count`, in ledger
ordinal order, without creating a binary event. This includes a legitimate restoration after
the last bus event. An EOF install is allowed only if the last raw event satisfies the same
exact triggering-fetch rule above. Reject boundaries greater than `event_count`, leftover
unconsumed rows, and any frame/boundary inconsistency. Install frames equal the triggering
fetch's frame. An interior restoration frame must lie between the immediately preceding and
next raw event frames (inclusive); an EOF teardown restoration uses the terminal observer frame
recorded by the footer and cannot precede the last raw event's frame. Every ledger frame must
be nondecreasing and within the observed start/terminal interval.

Active engine rewrites are permitted at the
same observation endpoint if the emulator normally retains them; do not force a synthetic
restore or change teardown ordering to make state empty. The ledger is complete for the
observation interval, not a promise that no future host operation occurs after core teardown.

## 4. Attached finite source inventory and three boundary corrections

Read this amendment together with [the finite inventory review](q028-m68k-finite-inventory-review.md).
The machine-readable attachment is
`analysis/evidence/vr60-q028-renderer-descriptor-probe/diagnostics/r2-full-raw-scan/q028-m68k-finite-inventory.json`,
SHA-256 `a09955793f72928a4c9133672aa9c7d2319c6e21d4933981a138afffb70edee8`.
It defines 321 source-backed instructions in 120 finite half-open spans, including all 256
diagnostically missing starts and 65 source-defined siblings. Its exact linked bytes, instruction/
span hashes, source file identities, and complete dispatch blocks—not the failed run's PC set—
define the proposed additional static candidates. Reject any mismatch against the pinned
ordinary ROM, reviewed decoder, or these byte ranges; retain conservative attribution claims.

The three incorrect historical instruction boundaries require these exact byte-identical
source-presentation corrections and exclusions before generic listing decode:

1. `race_start_countdown_sequence.asm`: represent `[009ECA,009F16)` as its 19-longword pointer
   table. The false instruction at 9F14 overlaps real `[009F16,009F1A)` CLR.W `$90B0.w`
   (`427890B0`). Emit the table and real CLR.W faithfully; 9F14 must not remain an instruction.
2. `track_graphics_and_sound_loader.asm`: represent `[00C7C2,00C7E8)` as the declared animation
   prefix and four-word timing table. The false ORI.L at C7E6 overlaps real `[00C7E8,00C7EE)`
   LEA `$0089AF3C,A0` (`41F90089AF3C`). Exclude the data and old overlapping row; retain the
   direct JSR entry at C7E8, proved by hardware initialization.
3. `display_state_timer_flag_update.asm` / section edge: byte range `[008200,008202)` is the
   final address extension of `[0081FC,008202)` CMPI.B `#$BE,$C8A4.w` (`0C3800BEC8A4`), not an
   AND.L instruction. Present the cross-section instruction/extension faithfully, with no
   independent start at 8200. The next real instruction remains BEQ.S at 8202. The complete
   source-called raw prefix `[0081D8,008202)` is retained, not only its sampled starts.

Known DATA exclusions also take precedence over mnemonic text at `[00BC30,00BC40)` (four
scene-command pointers) and `[030FE0,031094)` (180-byte PSG frequency table). Preserve complete
executable sibling tables `[00BC1C,00BC30)`, `[0305C4,030604)`, `[03109E,03111A)` (31 BRA.W
entries), and `[031124,031144)` (eight entries). The unrolled transfer block is exactly
`[0188EC,0189EE)`: 128 MOVE.W words plus RTS; following data is excluded.

Keep the attachment's old source hashes as pre-correction evidence. For every authorized
presentation edit retain the new source hash, full clean ordinary/probe ROM identity checks,
and identical affected span bytes. No broadened source cleanup, behavior fix, instruction
optimization, symbol relocation, or numeric opcode change is authorized by this presentation
amendment. If the assembler cannot express a corrected cross-section instruction without
moving bytes, preserve explicitly labeled opcode/extension words rather than change layout.

## Required tests and review boundary

Use original source templates plus actual new-core artifacts. Verify normal/alternate install
collision at FF0000, both mutable fields, partial-width writes, wrong copy PC/value/count,
unknown immutable-byte write, interrupted copy, stale view, and wrong CPU. Test actual RAM
byte/model mismatch detection without an extra emulated read. Mutate masked identity/mask
and remove a write that establishes the live operand; both must fail.
Test all four valid boot-view starts and rejection of copied VDP data at FF0014..FF001F;
prove that FF0014 remains independently valid when the completed normal template defines it.

For host rewrites: original→fake→restore, both idle/non-idle handler aliases, mismatched old/new
words, rejected registration, missing/duplicate/reordered/orphan ledger rows, changed boundary,
unregistered PC, stale template reinstall, and raw fake-word preservation. Verify that record
ordering rejects an install moved earlier while its old/new word transition still looks valid;
also reject a boundary after a different event and a mismatched triggering-fetch frame/PC.
Test restoration after the full source expression, not its intermediate value; apply a valid
EOF restoration with no synthetic access; reject `event_count+1`, unconsumed EOF rows and wrong
EOF frames. Verify that record
count/order/CPU/agent values are untouched by host-ledger emission. Retain source/core identities
and require a bounded real run beyond frame398 (SRAM onset) and frame360 (idle detection), with
all binary records through the production reader and zero loss/error/unattributed counts.

Validate all 120 attached spans and 321 starts against exact bytes/decoder boundaries. Reject
historical false starts 9F14, C7E6 and 8200; reject every declared DATA start while accepting the
neighboring true entries and cross-section CMPI extension. Mutation cases must include an
overlapping instruction, changed span/source identity, truncated extension, missing sibling
branch, and data-table promotion. These checks complement, not replace, real-stream tests.

The finite inventory is now part of this combined proposal. Fresh Auditor review is required
before its new admission rules or byte-identical presentation corrections are implemented;
no new full pilot is authorized by this amendment. All previously required actual-artifact,
reproducible-build, ordinary/probe identity and fresh completed-diff gates remain in force.

AUDITOR REVIEW REQUESTED for the combined mutable/host-rewrite/finite-source amendment.
