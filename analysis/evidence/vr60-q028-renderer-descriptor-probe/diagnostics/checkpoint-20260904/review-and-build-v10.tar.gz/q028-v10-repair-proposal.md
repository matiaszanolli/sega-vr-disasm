# Q-028 complete access-domain repair proposal — 2026-09-04

Status: PROPOSED, not implemented. Worker `worker_q028`.

## Purpose and fixed boundary

Repair the host observation and validation chain so the exact ordinary-ROM resource pilot can
produce complete attributable records that the production reader actually accepts. Preserve the
ordinary ROM, all A/B/C ROM identities, immutable 1,340-frame input, 48-byte access record and
64-byte chunk header ABI, existing numeric CPU/agent IDs, event order, raw accesses, capture
window, unfiltered semantics, all storage caps/floors, and quarantine. No SH2/game/COMM hardware
behavior changes. A passing resource pilot remains ineligible for schedule/family/campaign use.

Do not rerun the full pilot after only fixing its first rejected field. The r2 terminal footer
has 1,212 errors and 63,806,555 unattributed events in addition to the fetch-slot defect. The
unchanged r2 bytes are diagnostic inputs, never repairable or promotable acceptance evidence.

## Evidence and unresolved coverage

- r2 producer completed 1,340 frames; gate session 61766 exited 1 with `fetch slot`.
- First record: CPU0 fetch PC `$3F0`, width6, site1373, slot0. After `memset(record,0)`,
  `q028_all_access_observer.inc:327` fetch branch omits assignment of packed access_slot.
- Reset reads at sequences 57465..57468 are Master/Slave CPU reads of address0 then4 before
  any instruction fetch. Both slots are0. Pinned `cpu/sh2/sh2.c:47` performs these reads;
  `docs/sh7604-hardware-manual.md` sections4.1.2 and4.2.2 define the PC/SP reset-vector sequence.
- Pinned `pico/32x/memory.c:get_bios` builds distinct Master/Slave BIOS images when external
  BIOS inputs are null, and also generates the 68K adapter BIOS. The current ordinary-ROM-only
  site map has no image identity for these bytes. Raw missing sites include Master `$210/$212/
  $214`, Slave `$204...`, and 68K `$C0...$D2`.
- Linked `disasm/sections/code_200.asm:71` contains `dc.w $227B,$0014` at file `$169C`.
  The standalone mnemonic `main-loop/vint_handler.asm` is not linked here. Linked
  `input/joypad_read_port.asm:24` contains LEA `$41FA,$0044` at `$19AC` and another raw LEA at
  `$19B4`. `q028_owner_analysis.parse_listing` excludes dc.w and loses all these true starts.
- The same parser drops every address >= `$020200`, excluding 68K sound code at file
  `$030000+`, reached explicitly by JSR `$008B0000` from linked sound dispatchers. Sound entry
  bytes in `code_2e200.asm` and mnemonic functions in `code_30200.asm` are both in scope.
- Raw late records show Master on-chip SRAM execution at `$C00001F8+`; old prose claiming
  all SRAM rendering belongs to Slave cannot establish actor identity. Source has several finite
  copy payloads, not one universal alias: file `$02252C` copies437longwords from `$0600254C`,
  `$023348` copies402longwords from `$06003368`, and `$023A52` copies145longwords from
  `$06003A70`, each to `$C0000000`. Exact opcodes/literals must establish their domains and
  actor/runtime use before admitting any SRAM site. Existing comments incorrectly call SRAM VDP.
- The command observer watches Master COMM0 (`A15120/21`) while its `cmd02_entries` counter
  observes Slave execution at `$06000FA8` through COMM2. These are independent dispatch routes.
  The command CSV has1,239 high-byte submits and28 recognized low-byte command02 writes;
  `1,239 - 28 + 1 = 1,212` exactly explains errors from a pending02 assumption plus the
  hardcoded67 terminal check. This is not proof that28 and67 should agree.
- r2 reports Master DREQ0 47,038hook entries/188,152records while the pilot inventory calls it
  N/A. The inventory must be corrected from pinned FIFO-hook semantics, not a zero-transport
  assumption based on unrelated DMAC channel enable bits.

A read-only native scan of all1,987chunks is still running (session83569); it has verified
contiguous sequence through125,000,000records and reports only the four reset context mismatches
so far. Final attribution groups and any later context mismatches are pending. This proposal
requires closure of those groups before a full corrected pilot, not a guessed exhaustive list.

## Proposed implementation

1. **Emit the existing fetch sentinel.** Initialize packed `record.access_slot=0xFFFF` before
   branch-specific data assignment. Preserve zero-based operand slots and all other fields.
   Reject malformed fetch slots in the reader exactly as today.

2. **Model reset as an explicit non-instruction CPU phase.** Retain CPU identity and dedicated
   `synthetic-reset-vector` site classification. On the source-backed reset hook begin/end,
   expect exactly two read32 transactions in order, addresses0 then4, with values bound to
   the reviewed BIOS vector image; give them distinct phase-local slots0/1. Set no artificial
   instruction-fetch context. End reset before the first real fetch. Reader verifies this finite
   phase and rejects extra/missing/reordered/wrong-width/write transactions, any reset read after
   first fetch without a real reset-entry marker, and every synthetic-reserved site. Do not add
   a general `pc==0` exception. Only power-on boot is in this pilot; broader reset coverage is
   separate unless an actual later reset entry appears in the raw source trace.

3. **Complete the source-bound executable image inventory.** Add generated 68K/Master/Slave
   BIOS images with independent names, exact pinned producer-source hash, vector/code ranges,
   and full byte hashes; prove runtime BIOS-null selection and bytes before accepting events.
   These are emulator bootstrap images, never relabeled cartridge ROM. Include the linked sound
   CPU ranges and explicit raw-word instruction islands in the M68K decoder input. Decode full
   instruction lengths/extensions from linked bytes, not the observer's width2 fallback. Preserve
   source provenance and separate non-code/literal words; merely seeing a PC in this failed trace
   is not sufficient to declare arbitrary nearby data executable. Conservative candidate starts
   within a reviewed executable range may remain explicitly conservative, never a global safety
   proof. Static completeness checks cover every linked mnemonic and every reviewed raw-code
   island, while missing/unsupported runtime starts continue to fail closed.

4. **Bind finite on-chip SRAM payload views.** Decode each actual source copy loop and exact
   count/source/destination literals. Add only its finite executable payload view(s), keyed by CPU,
   PC, and exact opcode bytes, with copy-origin identity. If multiple payloads overlap, retain
   their separate identities and require the observed copy/byte state to choose the active one;
   do not assume a permanent `$C0000000` alias or an actor from outdated documentation. Reject
   fetches outside a proven installed payload, stale payload hashes, and unknown code writes.
   Final raw-group classification determines which reviewed views this pilot actually exercises.

5. **Repair command observation on its actual route.** Record the observed COMM0 lane writes
   for all command bytes without treating every high-byte1 submission as pending command02.
   Keep independent Master-command submission/ack state and Slave cmd02 execution counters;
   never force equal ordinals. Source/manual-backed byte-lane handling must account for width1/2/4
   writes that overlap the two COMM0 bytes, retaining original address/width/value and chronology.
   Do not mutate emulated registers. Terminal logging must always emit and close a complete
   footer before reporting semantic errors; replace the fixed cross-route67 test with consistent
   per-route state/terminal checks. Required later scheduling facts belong to the prospective
   schedule validator, not a resource-only observer's guessed command total.

6. **Correct the non-CPU agent contract.** Prove the existing DREQ hook's actual source meaning,
   mark Master DREQ0 applicable for this fixture, and bind the declaration to the observed hook
   and record counts. N/A must mean both no records and no hook entries, not merely an explanatory
   string. Require exact agent-key cardinality and reject missing/extra agents. This is observational
   inventory repair; no emulated channel/transport is enabled by the tooling change.

7. **Compose a real binary regression and only then launch.** Extend the existing six-frame
   real-core test to load the exact generated map and pass all emitted chunks to production
   `read_events()` and `validate_idl()`, reconcile every footer count and identity, assert real
   fetch/data on eachCPU and zero error/unknown/unattributed/dropped/open context, and prove the
   reset and BIOS phases above. Use the actual emitted artifacts for mutation cases: sentinel,
   reset order/address/value/phase, reserved site, wrong image/opcode, missing chunk, bad count,
   and false-N/A agent. Add deterministic source-derived SRAM/sound image/view checks, and a
   bounded real run long enough to exercise any domain absent from six-frame boot, with length
   justified by the diagnostic first-occurrence inventory before launching. These diagnostics
   never become an eligible schedule or substitute for the fixed1,340-frame pilot.

## Acceptance before another full pilot

Fresh Auditor approves the complete diff; ordinary/prior ROM identities and source pack stay
exact. Full raw diagnostic aggregation closes every unattributed group/context cause; no unexplained
group is waved through. All reviewed source domains regenerate and compare exactly. Two clean
offline builds match; clean ROM rebuild and existing scoped tests pass. The real-core binary
producer/reader regressions pass with strict counters and meaningful malformed-artifact rejection.
Then, and only then, launch a new-directory full1,340-frame resource pilot under unchanged caps.

The separate later v8 campaign integration/schedule-bound validator/archive-resource proposal
remains necessary. This repair must not quietly change the v7 campaign policy or claim a Q-028
family result, bridge, authority, cadence, or FPS improvement.

## Concrete ABI and image-selection details for audit

**Reset without a record-layout extension.** For this boot-only fixture each SH2 reader starts
in RESET_PC, progresses to RESET_SP on its exact synthetic read32 of address0/value `$204`/slot0,
then to AWAIT_FIRST_FETCH on read32 address4/slot1 with Master `$06040000` or Slave `$0603F800`.
These values come from the separately pinned generated BIOS images. The next event from that
CPU must be its real fetch at `$204`, sentinelFFFF and matching BIOS image/site. Thereafter
synthetic-reset/reserved sites are forbidden. Interleaved events from other CPUs do not advance
this CPU's phase. No fetch is fabricated and no existing data event is relabeled. Producer
tracks the same two prefetch reset slots and rejects any other prefetch CPU-data event. Broader
manual/repeated-reset semantics are outside this fixture and cannot use this finite boot policy.

**SRAM identity cannot be selected only by first opcode.** Exact ordinary-ROM payload hashes:

- file `$02254C`,1748bytes: `e57a4941316923bd1ef94cf3a566dabdd4e856c34484761cdade00b498f37b4b`;
- file `$023368`,1608bytes: `fb54b63faa6a69e87df6e4c1d1e5c3ef09be232d0c8816c3017578e4082f17e6`;
- file `$023A70`,580bytes: `53969eba802b7627b6e7b524330867ce5a8a6b86afdb2837794824aaad130bb7`.

For these source-derived candidate views, full two-byte SH2 opcodes collide at the same SRAM PC:
first/second payload offsets4E,D2,2C8,4F0; first/third offset0; second/third CC,136,17C,232.
Thus extend the generated internal lookup key with an image-view ID (the packed record stays
unchanged because `static_site_index` selects a row containing that image-view ID).

Maintain per-CPU SRAM installation state in the passive observer and independently reconstruct
it in the raw reader. A recognized copy begins only at the exact reviewed loop's first source
read and first destination write. Match each subsequent read/write pair by CPU, exact source/
destination/count/stride/width/value and loop PC against the pinned payload. Invalidate the old
view when a copy starts; after the entire exact payload installs, activate its view ID. A SRAM
fetch requires an active view and matching opcode at its bounded destination offset. Unexplained
writes overlapping installed code invalidate that view and fail later use; no permanent blanket
alias is accepted. Every fetch's site-index image identity must match the independently computed
active view. A duplicate `(CPU,view,PC,opcode)` key with unequal site definitions is a build error.
Whether all three candidate views are exercised and which CPU installs each remains subject to
the full raw scan/copy evidence; source existence alone does not claim execution.

**Header identity joins.** Existing generator code defines image prefix as SHA256(ordinaryROM),
tool prefix as SHA256(q028_owner_analysis.py), and site prefix as SHA256(canonical site-map JSON).
The second prefix is the analyzer, not the runtime observer. Retain these exact semantics and
compare all three prefixes of every chunk against those independently recomputed inputs (not
only nonzero and cross-chunk consistency). Bind the analyzer/observer/map/core/frontend full
digests to the clean-build postimages and source manifest; verify those hashes against actual
files before a run. Do not call a supplied toolchain-file hash alone provenance validation.
Require exact header ordinal/count/firstsequence/reserved bytes as today, and add a mutation
where every chunk consistently carries the same wrong prefix, which must still fail.

## Finite decoder and bootstrap recipe amendment

**M68K decoder and starts.** Use the installed GNU Binutils2.46
`m68k-linux-gnu-objdump -D -b binary -m m68k:68000` (record full executable/version hashes).
Do not use the generic family default, which can decode instructions unavailable to68000.
Retain all linked mnemonic starts below020200 and additionally mnemonic starts in the source-
proven sound range `[030200,031688)`. `sound_master_flag.asm` ends with RTS at031686;
`code_30200.asm` begins embedded Z80 bytes at031688, which are explicitly outside this M68K
range. Restore these finite raw-code islands, with half-open file-byte intervals:

- `[000414,000418)` reviewed adapter BNE.W;
- `[00169C,0016A0)` linked indexed MOVEA.L;
- `[0019AC,0019B0)` and `[0019B4,0019B8)` linked joypad LEAs;
- `[030000,030200)` contiguous source-authored sound code; its last instruction is
  MOVEA.L at0301FC through0301FF, and execution continues into the mnemonic section;
- `[030248,03024A)` BEQ.S, `[030296,030298)` BNE.S, and `[030402,030404)` RTS.

Sequentially decode each explicitly contiguous island from its start, consuming full extension
words and requiring exact tiling to its end. Decode each mnemonic start independently and check
decoded bytes/length against the complete listing encoding including continuation words. Reject
invalid `.word`, truncated instructions, length outside2..10, mismatched listing bytes, or a start
inside an already established instruction's extension. Do not promote sound tables or Z80 bytes
to M68K code. Additional missing starts revealed by the full aggregate require an explicit source-
backed range amendment before code; they do not enter through a runtime-PC allowlist.

**Builtin BIOS images and legal entry regions.** Use exactly the pinned `get_bios` source recipe
and its `msh2_code`, `ssh2_code`, `andb`, and `p_d4` arrays. Independently materialize canonical
CPU-order byte arrays of256/2048/1024bytes for 68K/Master/Slave. Initial bytes are zero because
pinned `pico/32x/32x.c:130` zeroes the entire `Pico32xMem` allocation. The 68K recipe fills its
vector trampolines, NOPs and two helpers; the SH2 recipes fill vectors then copy their arrays and
set power-on/manual vector pairs. Reject external BIOS and the CD/MSU alternative for this exact
cartridge fixture. Parse only hex u16 literals and the exact two-character constant expressions
used by the arrays; require their source hashes and expected array lengths before evaluation.

Finite code versus data classification, all half-open addresses:

- 68K adapter BIOS: vectors `[0000,00C0)` are data; NOP/helper instruction stream
  `[00C0,0100)` is decoded as68000. Its original source array generates helper C8,D2,D4,FE.
- Master BIOS: vector data `[0000,0140)`; NOP/trap/start code `[0140,0220)`;
  literals `[0220,022C)`; CD routine code `[022C,0264)`; literals `[0264,0270)`;
  zero-filled `[0270,0800)` is never an executable site.
- Slave BIOS: vector data `[0000,0200)`; trap/start code `[0200,0220)`;
  literals `[0220,022C)`; CD routine code `[022C,023C)`; literals `[023C,0240)`;
  zero-filled `[0240,0400)` is never an executable site.

Record all generated image bytes and hashes in the map's source manifest. Add a passive hook
immediately after `get_bios()` completes in `PicoMemSetup32x`, before reset consumption, to emit
the three full runtime arrays serialized in CPU byte order (not host raw word order), BIOS-null
flags and cartridge-mode flags. Compare them byte-for-byte to the independent generated images
before the reader admits a bootstrap site. Existing real reads/fetches remain the only bus
records; serialization does not issue extra emulated memory reads. Mismatched runtime images
remain a failure even if their words happen to decode. Bootstrap helper inputs may address game
ROM, but their instruction image identity remains distinct from ordinaryROM.

**SRAM writable scratch boundary.** For the three exact copied regions, preserve their exact
installed byte spans `[C0000000,C00006D4)`, `[C0000000,C0000648)`, and
`[C0000000,C0000244)` respectively. Source literals in the renderer put context/edge storage at
`C0000700` and `C0000740`; retained late raw accesses at0702/0724/0770/0774/0778/0794/0796 are
outside all three installed spans. Those scratch writes do not invalidate code. No address
inside a payload is granted mutable-data exemption merely because a write was observed: only
source-classified data/literal intervals may receive such an exemption, and instruction fetches
from a declared data interval remain forbidden. Any unexplained installed-span write fails use
until a complete reviewed reinstall; unknown regions or variants stay unattributed. The exact
instruction/data bitmap inside each copied span must be produced from its decoded direct control
flow and source literal references and included in the reviewed generated-map diff before this
item is considered implemented. This bitmap is still a review obligation, not silently inferred
from all even words or the failed run's observed instruction PCs.

## Resource-only COMM facts amendment (supersedes transaction language in item5)

The authoritative binary stream retains every original CPU read/write overlapping COMM0–COMM3
exactly once with its real CPU/PC/address/width/value. Derive annotations from those records;
do not duplicate polling reads in an auxiliary CSV or fabricate accesses. Split original width1/2/4
values into lane effects using big-endian byte extraction and the actual covered addresses, while
retaining a single source sequence ID for the original access. No additional emulated reads.

Use two annotation phases, not a guessed command-completion state machine:

- BOOT: generated Master BIOS PC218 writes M_OK to4020..4023; Slave BIOS PC216 writes S_OK
  to4024..4027. Linked68K bootstrap reads those at808/810 (alternate8D0/8D8), then clears
  COMM0:1 at81A (alternate8E2). Preserve earlier clears, ASCII values, reads and the selected
  source-proven bootstrap route as BOOT facts. They are never game submits or acknowledgements.
- GAME begins only after the source-proven bootstrap-clear boundary. Annotate 68K HI=1 as
  `trigger_write`; any command-low-lane update as `command_lane_write`; Master HI=0 as
  `busy_clear`; Master HI=1 as `trigger_restore`; and COMM1_LO updates as `signal_write`.
  Low-byte zero can mean parameter consumption in cmd22/cmd25, not completion. Writes without
  one of these semantic tags still retain their exact raw record and lane effect.

Any compact command CSV must declare its write subset and contain a bijection to matching raw
sequence IDs, with exact frame/CPU/PC/address/width/value and computed lane effects. Bootstrap
read predicates consume existing raw records. Counts/last IDs/final reconstructed lane state are
recomputed from the raw stream and compared to observer footer metadata. Do not require equality
among trigger writes, busy clears, signal writes, or Slave cmd02 counts. Do not call4023 bit1
writes acknowledgements: source `$06004464` signals DMA setup; `$06004400` and other command
paths clear busy separately, sometimes after signaling or while redispatching.

Terminal success requires flushed/closed observer streams, complete raw sequence/count identity,
and no open observation callbacks; it does not require the emulated Master command to be idle.
The fixture may stop during normal work, and the resource gate never established an idle endpoint.
Always write terminal metadata before reporting semantic errors, and always close files even if
a prior semantic predicate failed. Slave invocation/context checks remain independent. A full
cross-CPU command lifecycle acceptance contract belongs to later source-bound schedule validation;
this resource repair removes false semantics while preserving complete raw observation.

## Closed SRAM policy: conservative byte provenance, not an inferred code bitmap

This supersedes the internal instruction/data-bitmap obligation above. The source proves exact
copied bytes and destinations; it does not justify calling every word in those blobs an instruction
or promising that no embedded data changes. Model each installed payload as a **byte-provenance
view**, with candidate fetch sites at every even offset whose two bytes decode as a valid SH2
instruction under `sh-elf-objdump -m sh2`. Give them classification
`conservative-copied-byte-fetch`, not `resolved-executable` or `literal-proven-safe`. Unsupported
words are explicit non-fetch candidates and fail if fetched. Operand sites attached to candidate
fetches stay conservative dynamic memory-access sites. This finite candidate map does not claim
that all words execute, that literals are executable by intent, or that unobserved words are safe.

Admission of an actual SRAM fetch requires all of: the correct CPU has completed the exact
source-bound install; the byte-provenance view is still valid; fetch offset is aligned and fully
inside its installed extent; the two actual fetched bytes equal that view's original bytes;
the emitted static-site row carries that same view/offset/word; and the independent reader's
reconstructed install state agrees. Matching an opcode from some other possible payload is not
sufficient, even when it decodes identically.

Any CPU write overlapping **any byte** of a currently installed extent invalidates that view,
except the monitored writes of a complete reviewed install already in progress. This includes
writes that might be mutable literals/data: they are not silently exempted or labeled corruption,
but subsequent fetches fail because this observation model no longer has proven byte provenance.
Only another complete verified install restores a view. The reader must reproduce every
invalidation from original raw writes. No mutable-inside-payload special cases are proposed.
Source-proven scratch at0700+ lies beyond all three extents and does not invalidate them.

Thus this gate makes a positive source-copy/byte-identity claim at each observed fetch, never a
global code-versus-data or immutability claim. If real runtime writes legitimately change an
installed payload before later execution, preserve that failure for source research; do not
invent a bitmap or accept new bytes from the failed outcome. Test install interruption, a
one-byte interior write, wrongCPU copy, incomplete copy, copyvalue mismatch, stale view, and a
samePC/sameopcode different-view collision through actual reader state.

AUDITOR REVIEW REQUESTED — amended proposal, full raw-group closure pending.
