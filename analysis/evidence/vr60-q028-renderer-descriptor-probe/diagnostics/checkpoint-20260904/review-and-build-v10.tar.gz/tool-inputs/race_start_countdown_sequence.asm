; ============================================================================
; race_start_countdown_sequence — Race Start Countdown Sequence
; ROM Range: $009EC0-$00A050 (400 bytes)
; Multi-phase race start countdown dispatcher. Jump table at $009ECA
; selects phase: initial delay, "3-2-1" countdown with sound triggers
; ($C0-$C3), green light, and random tire screech. Manages SH2
; communication flags, display list entries, and race state transitions.
; PRNG at end generates random crowd noise timing.
;
; Uses: D0, D6, D7, A0, A1
; Confidence: high
; ============================================================================

race_start_countdown_sequence:
        MOVE.W  (-14164).W,D0                   ; $009EC0
        MOVEA.L $009ECA(PC,D0.W),A1             ; $009EC4
        JMP     (A1)                            ; $009EC8
        ; 19 absolute phase pointers, $009ECA-$009F15 (DATA, not opcodes).
        dc.l    $0088A04E,$00889F16,$00889F2A,$00889F4A
        dc.l    $00889F6C,$00889F8E,$00889FBC,$0088A04E
        dc.l    $00883D9A,$00883DA6,$00883DD4,$00883E08
        dc.l    $00883E58,$00883E64,$00883E7E,$00883EA2
        dc.l    $00883EC6,$00883EF6,$00883F2C
        CLR.W   ($FFFF90B0).W                   ; $009F16: true second entry
        CLR.W  (-14166).W                       ; $009F1A
        MOVE.B  #$01,$00FF6990                  ; $009F1E
        ADDQ.W  #4,(-14164).W                   ; $009F26
        CMPI.W  #$003C,(-14166).W               ; $009F2A
        BLT.W  .loc_0162                        ; $009F30
        ADDQ.W  #4,(-14164).W                   ; $009F34
        CLR.W  (-14166).W                       ; $009F38
        MOVE.B  #$09,$00FF6980                  ; $009F3C
        MOVE.B  #$C0,(-14172).W                 ; $009F44
        CMPI.W  #$0014,(-14166).W               ; $009F4A
        BLT.W  .loc_0162                        ; $009F50
        ADDQ.W  #4,(-14164).W                   ; $009F54
        CLR.W  (-14166).W                       ; $009F58
        MOVE.L  #$222F038A,$00FF6988            ; $009F5C
        MOVE.B  #$C1,(-14172).W                 ; $009F66
        CMPI.W  #$0014,(-14166).W               ; $009F6C
        BLT.W  .loc_0162                        ; $009F72
        ADDQ.W  #4,(-14164).W                   ; $009F76
        CLR.W  (-14166).W                       ; $009F7A
        MOVE.L  #$222F002C,$00FF6988            ; $009F7E
        MOVE.B  #$C2,(-14172).W                 ; $009F88
        CMPI.W  #$0014,(-14166).W               ; $009F8E
        BLT.W  .loc_0162                        ; $009F94
        ADDQ.W  #4,(-14164).W                   ; $009F98
        CLR.W  (-14166).W                       ; $009F9C
        CLR.B  $00FF6990                        ; $009FA0
        MOVE.L  #$222EEF3A,$00FF6988            ; $009FA6
        BSET    #4,(-15602).W                   ; $009FB0
        MOVE.B  #$C3,(-14172).W                 ; $009FB6
        CMPI.W  #$0005,(-14166).W               ; $009FBC
        BNE.S  .loc_0118                        ; $009FC2
        MOVE.B  #$82,(-14171).W                 ; $009FC4
        BTST    #5,(-14322).W                   ; $009FCA
        BEQ.S  .loc_0118                        ; $009FD0
        MOVE.B  #$93,(-14171).W                 ; $009FD2
.loc_0118:
        CLR.W  (-16346).W                       ; $009FD8
        TST.B  (-15598).W                       ; $009FDC
        BNE.S  .loc_013C                        ; $009FE0
        MOVEQ   #$00,D0                         ; $009FE2
        BTST    #2,(-14165).W                   ; $009FE4
        BNE.S  .loc_012E                        ; $009FEA
        MOVEQ   #$09,D0                         ; $009FEC
.loc_012E:
        MOVE.B  D0,$00FF6980                    ; $009FEE
        CMPI.W  #$003C,(-14166).W               ; $009FF4
        BLT.S  .loc_0174                        ; $009FFA
.loc_013C:
        ADDQ.W  #4,(-14164).W                   ; $009FFC
        LEA     $00FF66DC,A1                    ; $00A000
        CLR.W  (A1)                             ; $00A006
        CLR.W  $0014(A1)                        ; $00A008
        CLR.W  $0028(A1)                        ; $00A00C
        CLR.W  $003C(A1)                        ; $00A010
        MOVE.W  #$FFFF,(-16346).W               ; $00A014
        CLR.B  $00FF6980                        ; $00A01A
        BRA.S  .loc_018E                        ; $00A020
.loc_0162:
        MOVEQ   #$00,D0                         ; $00A022
        BTST    #2,(-14165).W                   ; $00A024
        BEQ.S  .loc_016E                        ; $00A02A
        MOVEQ   #$01,D0                         ; $00A02C
.loc_016E:
        MOVE.B  D0,$00FF6990                    ; $00A02E
.loc_0174:
        MOVE.W  (-28496).W,D0                   ; $00A034
        ADDQ.W  #1,(-28496).W                   ; $00A038
        MULU    #$3BBB,D0                       ; $00A03C
        SWAP    D0                              ; $00A040
        CMPI.W  #$001B,D0                       ; $00A042
        BLE.S  .loc_018A                        ; $00A046
        MOVEQ   #$1B,D0                         ; $00A048
.loc_018A:
        MOVE.W  D0,(-16346).W                   ; $00A04A
.loc_018E:
        RTS                                     ; $00A04E
