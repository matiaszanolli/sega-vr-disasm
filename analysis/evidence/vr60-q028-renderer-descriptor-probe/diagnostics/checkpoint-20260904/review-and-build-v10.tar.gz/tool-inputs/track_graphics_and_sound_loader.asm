; ============================================================================
; track_graphics_and_sound_loader — Track Graphics and Sound Loader
; ROM Range: $00C7C2-$00C8E6 (292 bytes)
; Data prefix (animation frame table, 30 bytes). Loads track-specific
; graphics from ROM $0089B6AC/$0089B73C, copies palette data (54 longs),
; initializes sound/timing state variables. Second entry point loads
; track-specific overlay graphics from $00895488/$008954F4/$00895560
; indexed by race mode. Configures display viewport and clears
; display list at $FF60C0-$FF60D0.
;
; Uses: D0, D1, D3, D4, D7, A0, A1, A2
; Calls: $0048EA (data_copy), $004922 (FastCopy16)
; Confidence: high
; ============================================================================

track_graphics_and_sound_loader:
        ; Animation DATA ($00C7C2-$00C7DF), followed by four timing words.
        dc.w    $04A9,$0483,$0471,$046E,$0462,$0456,$0444,$0433
        dc.w    $0429,$040E,$03F3,$03E2,$03D7,$03C1,$03C0
        dc.w    $003A,$0050,$0064,$0083          ; $00C7E0 timing DATA
        LEA     $0089AF3C,A0                    ; $00C7E8: hardware-init entry
        LEA     (-4344).W,A1                    ; $00C7EE
        JSR     $008813B4                       ; $00C7F2
        LEA     $0089B6AC,A1                    ; $00C7F8
        LEA     (-1464).W,A2                    ; $00C7FE
        jsr     triple_memory_copy+32(pc); $4EBA $80E6
        jsr     triple_memory_copy+88(pc); $4EBA $811A
        LEA     $0089B73C,A1                    ; $00C80A
        LEA     (-598).W,A2                     ; $00C810
        MOVEQ   #$35,D7                         ; $00C814
.copy_palette_loop:
        MOVE.L  (A1)+,(A2)+                     ; $00C816
        DBRA    D7,.copy_palette_loop                    ; $00C818
        MOVEQ   #$00,D0                         ; $00C81C
        MOVE.B  D0,(-347).W                     ; $00C81E
        MOVE.B  D0,(-346).W                     ; $00C822
        MOVE.B  D0,(-341).W                     ; $00C826
        MOVE.B  D0,(-345).W                     ; $00C82A
        MOVE.B  D0,(-600).W                     ; $00C82E
        MOVE.B  D0,(-4345).W                    ; $00C832
        MOVE.B  D0,(-329).W                     ; $00C836
        MOVE.B  D0,(-335).W                     ; $00C83A
        MOVE.B  #$02,(-339).W                   ; $00C83E
        MOVE.B  #$02,(-338).W                   ; $00C844
        MOVE.B  #$FF,(-348).W                   ; $00C84A
        MOVE.B  #$00,(-14299).W                 ; $00C850
        JMP     $0088A83E                       ; $00C856
.display_list_init:
        MOVEQ   #$00,D1                         ; $00C85C
        LEA     $00FF6000,A1                    ; $00C85E
        JSR     $00884836                       ; $00C864
        JMP     $0088483E                       ; $00C86A
        BSR.S  .display_list_init                        ; $00C870
        MOVE.W  (-14132).W,D0                   ; $00C872
        LEA     $00895488,A1                    ; $00C876
        MOVEA.L $00(A1,D0.W),A1                 ; $00C87C
        TST.B  (-14321).W                       ; $00C880
        BEQ.S  .load_overlay_gfx                        ; $00C884
        LEA     $00895560,A1                    ; $00C886
        MOVEA.L $00(A1,D0.W),A1                 ; $00C88C
        LEA     $00FF6330,A2                    ; $00C890
        JSR     $00884920                       ; $00C896
        LEA     $008954F4,A1                    ; $00C89C
        MOVEA.L $00(A1,D0.W),A1                 ; $00C8A2
.load_overlay_gfx:
        LEA     $00FF6100,A2                    ; $00C8A6
        JSR     $00884920                       ; $00C8AC
        MOVE.W  (A1)+,(-16300).W                ; $00C8B2
        MOVE.W  (A1)+,(-16298).W                ; $00C8B6
        MOVE.L  (A1)+,(-16184).W                ; $00C8BA
        MOVE.W  (A1)+,(-16180).W                ; $00C8BE
        MOVE.W  (A1),$00FF60CC                  ; $00C8C2
        MOVE.W  #$0070,$00FF60CE                ; $00C8C8
        LEA     (-16210).W,A1                   ; $00C8D0
        MOVEQ   #$00,D1                         ; $00C8D4
        MOVE.L  D1,(A1)+                        ; $00C8D6
        MOVE.L  D1,(A1)+                        ; $00C8D8
        MOVE.L  D1,(A1)                         ; $00C8DA
        MOVE.L  #$00FF9000,(-14200).W           ; $00C8DC
        RTS                                     ; $00C8E4
